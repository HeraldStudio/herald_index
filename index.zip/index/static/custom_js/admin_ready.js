/**
 * Created with PyCharm.
 * User: wolf
 * Date: 13-10-21
 * Time: 下午1:17
 * To change this template use File | Settings | File Templates.
 */




$(document).ready(function(){
    setPubLinkClick();
    setPubNewsClick();
    setResetLinkClick();
    setResetNewsClick();
    setPubRecClick();
    setResetRecClick();
    setNewsNextPage();
    setNewsPrePage();
    setRecNextPage();
    setRecPrePage();
    setModLink();
    setPubWrapper();
    setResetWrapper();
    setWrapperNumClick();
    setPubAppClick();
});

