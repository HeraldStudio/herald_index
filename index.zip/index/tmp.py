
# -*- encoding: utf-8 -*-


if __name__ == "__main__":
    dic = {}
    print dic.get("hhh")